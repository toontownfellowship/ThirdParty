#define LOGINFO    printf
#define LOGWARNING printf
