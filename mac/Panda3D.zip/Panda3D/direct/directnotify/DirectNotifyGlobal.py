"""instantiate global DirectNotify used in Direct"""

import DirectNotify

directNotify = DirectNotify.DirectNotify()
giveNotify = directNotify.giveNotify
