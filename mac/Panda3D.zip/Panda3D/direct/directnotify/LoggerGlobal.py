"""instantiate global Logger object"""

import Logger

defaultLogger = Logger.Logger()
