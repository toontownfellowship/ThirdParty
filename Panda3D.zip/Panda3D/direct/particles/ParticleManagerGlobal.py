"""
Contains the global particle system manager
"""
from pandac.PandaModules import ParticleSystemManager

particleMgr = ParticleSystemManager()
