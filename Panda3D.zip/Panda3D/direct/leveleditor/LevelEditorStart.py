import LevelEditor

base.le = LevelEditor.LevelEditor()
# You should define LevelEditor instance as
# base.le so it can be reached in global scope

run()
