print 'DirectStart: Starting the game.'

from direct.showbase import ShowBase
base = ShowBase.ShowBase()
